export class Address {
  id: string;
  society: string;
  houseno: string;
  landmark: string;
  zip_code: string;
  city: string;
  state: string;
  road: string;
  area: string;
}
