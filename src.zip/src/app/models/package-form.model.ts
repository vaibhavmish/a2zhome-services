export class PackageForm {
  name: string;
  number: string;
  type: string;
  email: string;
  message: string;
  location: string;
}
