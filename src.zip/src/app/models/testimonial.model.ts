export class Testimonial {
    _id: string;
    news_title: string;
    news_desc: string;
    news_photo: string;
    news_link: string;
}