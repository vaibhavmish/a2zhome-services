import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-comp-account',
    templateUrl: 'account.component.html',
    styleUrls: ['account.components.css']
})

export class AccountComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}