export class User {
    name: string;
    gender: string;
    number: string;
    email: string;
    photo: string;
    dob: string;
}
